import { combineReducers } from "redux";
import categoryReducer from "./reducers/categoryReducer";
import loginReducer from "./reducers/loginReducer";
import sideBarReducer from "./reducers/sideBarReducer";

export default combineReducers({
  category : categoryReducer,
  login: loginReducer,
  sidebarShow:sideBarReducer
});
