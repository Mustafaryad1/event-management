export const GET_ALL_CATEGORY = 'GET_ALL_CATEGORY'
export const LOGIN = 'LOGIN'
