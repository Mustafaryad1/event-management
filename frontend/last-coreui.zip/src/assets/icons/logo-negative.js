// here project logo

export const logoNegative = ['608 134', `
  <title>Survey System</title>

`]
