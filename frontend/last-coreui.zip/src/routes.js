import React from 'react';

const Dashboard = React.lazy(() => import('./views/dashboard/Dashboard'));
const Users = React.lazy(() => import('./views/users/Users'));
const User = React.lazy(() => import('./views/users/User'));
const Forms = React.lazy(() => import('./views/forms/list/list'));
const FormSubmssions = React.lazy(() => import('./views/forms/submissions/formSubmissions'));
const FormCreate = React.lazy(() => import('./views/forms/create/create'));
const Form = React.lazy(() => import('./views/forms/display/display'));
const Submission = React.lazy(() => import('./views/submissions/userData'));


const routes = [
  { path: '/', exact: true, name: 'Home' },
  { path: '/dashboard', name: 'Dashboard', component: Dashboard },
  { path: '/form', exact: true,  name: 'Forms', component: Forms },
  { path: '/form/list', exact: true,  name: 'Forms', component: Forms },
  { path: '/form/:id/submissions', exact: true,  name: 'Form Submissions', component: FormSubmssions },
  { path: '/form/create', exact: true,  name: 'Create Form', component: FormCreate },
  { path: '/form/display/:id', exact: true,  name: 'Form', component: Form },
  { path: '/submission/:id', exact: true,  name: 'User Submission', component: Submission },
  { path: '/users', exact: true,  name: 'Users', component: Users },
  { path: '/users/:id', exact: true, name: 'User Details', component: User }
];

export default routes;
