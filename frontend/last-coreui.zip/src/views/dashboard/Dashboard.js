import React from 'react'


const Dashboard = () => {
  return (
    <>
      <h1>Hello</h1>


    </>
  )
}

export default Dashboard
