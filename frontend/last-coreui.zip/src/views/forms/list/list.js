import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function CreateForm(props) {
    const [forms, setForms] = useState([])
    
    useEffect(()=>{
        axios.get("http://127.0.0.1:5050/form/list").then(res=>{
            setForms(res.data)
            console.log(forms)
        })
    },[])

    return (
        <div>
            <h1>Forms</h1>
            <hr/>
            {forms.map(form=>
                <div key={form._id} >
                    <h5 onClick={()=>{props.history.push(`/form/display/${form._id}`)}}>
                        {form.form.title}</h5>
                    <h5 onClick={()=>{props.history.push(`/form/${form._id}/submissions`)}}>
                        Submissions</h5>
                    <hr/>
                </div>)}
        </div>
    );
  
}