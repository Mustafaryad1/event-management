import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function CreateForm(props) {
    const { match: { params } } = props;
    const form_id =  params.id;
    const [submissions, setSubmissions] = useState([]);

    useEffect(()=>{
        axios.get(`http://127.0.0.1:5050/form/${form_id}/submissions`).then(res=>{
            setSubmissions(res.data.submissions)
        }).catch(err=>{
            console.log(err)
        })
    },[])

    return (
        <div>
            <h1>Submissions</h1>
            <hr/>
            {submissions.map(submission=>
                <div key={submission._id} onClick={()=>{props.history.push(`/submission/${submission._id}`)}}>
                    <h5>{submission._id}</h5>
                    <hr/>
                </div>)}
        </div>
    );
  
}