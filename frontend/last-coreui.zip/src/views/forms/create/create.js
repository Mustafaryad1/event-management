import React from 'react';
import {FormEdit, FormBuilder} from 'react-formio';
import axios from 'axios';

export default function CreateForm(props) {

  const f = { display: 'form' };
  const onSaveForm = (form)=>{
        if(form.title){
        axios.post("http://127.0.0.1:5050/form/create",form).then(res=>{
        alert("Survey Created")
            props.history.push("/form/list")
        }).catch(err=>{
        alert("Something Wrong")
        })}else{
            alert("you should add title")

        }
        props.history.push('/form/list')
    }
  return (
        <div>
            <h1>Create Form</h1>
            <hr/>

            <FormEdit 
                saveText="Create Form"
                
                form ={f}
                options = {{
                    builder: {
                        layout: false,
                        data: false,
                        basic: false,
                        advanced: false,
                        premium: false,
                        customBasic: {
                            title: 'Elements',
                            default: true,
                            weight: 0,
                            components: {
                              textfield:true,
                              datetime:true,
                              day:true,
                              time:true,
                              textarea: true,
                              uploadImage: {
                                title: 'Upload Image',
                                icon: 'image',
                                schema: {
                                  storage: "base64",
                                  label: 'Image',
                                  image:true,
                                  type: 'file',
                                  key: 'image',
                                  input: true
                                },
   
                            },
                            uploadImages: {
                                title: 'Upload Images',
                                icon: 'image',
                                schema: {
                                  storage: "base64",
                                  label: 'Images',
                                  image:true,
                                  type: 'file',
                                  key: 'images',
                                  input: true,
                                  multiple: true,
                                  persistent: false,
                                
                                },
   
                            }
                        }
                    }
                 }
                }}
            />
            <hr/>
            <div>
                <h3>Permissions</h3>
            </div>
        </div>
    );
  
}