import React, { useEffect, useState } from 'react';
import {Form} from 'react-formio';
import axios from 'axios';

export default function DisplayForm(props) {

    const [form, setForm] = useState({});
    const [submission, setSubmission] = useState({});
    const { match: { params } } = props;
    const form_id =  params.id;
    useEffect(()=>{
        
        axios.get(`http://127.0.0.1:5050/form/${form_id}`).then(res=>{
            let _form =  res.data.form.form;
            // _form.components[0].defaultValue="asd" to set data in the form
            // _form.components[2].defaultValue="15:10:10"
            setForm(_form)
            // console.log(form)
            // console.log(res.data.form.form)
        }).catch(err=>{
            alert("Not Found")
        })
    },[])
    
    const handleSubmit = (data)=> {
        const user_form_data = {data:{}};
       
        for(let user_data in data.data){ 
            form.components.map(item =>{
                if(item.key === user_data){
                   
                    user_form_data['data'][user_data] = {
                        id:item.id,
                        key:item.key,
                        value:data.data[user_data],
                        user:"user",
                        label:item.label,
                        input_type:item.type
                    }
                    return true;
                }
            })
        }
        // data.data = user_form_data;
        user_form_data["form_id"] = form_id;
        console.log(user_form_data)
        axios.post("http://127.0.0.1:5050/form/data",user_form_data).then(res=>{
            console.log("her i submit data ")
            setSubmission({data})
            console.log(res)
            props.history.push("/form/list")
        }).catch(err=>{
            alert("something Wrong")
        })
        // // console.log(data)
        // props.history.push("/form/list")
      }

  return (
        <div>
            <h1>Form</h1>
            <hr/>
            <Form 
                form={form} 
                submission={{ data: submission }}
                onSubmit={handleSubmit}  
                onSubmitDone={a => {
                    console.log(a);
                  }}
                options={{ template: 'bootstrap3', readOnly:false }}
                />
            
        </div>
    );
  
}