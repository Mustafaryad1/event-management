import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function CreateForm(props) {
    const { match: { params } } = props;
    const submission_id =  params.id;
    const [submission, setSubmission] = useState({form_fields:[]});

    useEffect(()=>{
        axios.get(`http://127.0.0.1:5050/form/submission/${submission_id}`).then(res=>{
            setSubmission(res.data.submission)
            console.log(res.data.submission.form_fields)
        }).catch(err=>{
            console.log(err)
        })
    },[])

    return (
        <div>
            <h1>Submission</h1>
            <hr/>
            {submission.form_fields.map(field=>
                <div key={field.id} className="border border-black p-2">
                    <p>{field.label}</p>
                    {field.input_type!=="file"?<h5>{field.value}</h5>:
                    <div>{[...field.value].map(image_src=>{

                         return image_src.includes("mp4")?
                         <video width="400px" height="300px" controls >
                            <source src={image_src} type="video/mp4"/>
                        </video>:
                         <img src={image_src} width="400px" height="300px" className="m-1"/>
                    })}</div>}

                </div>)}
        </div>
    );

}
